import './sass/style.scss';
import './css/fonts.css';
import './../node_modules/bootstrap-icons/font/bootstrap-icons.scss';
import './../node_modules/aos/dist/aos.css'
// import './../../node_modules/video.js/dist/video-js.min.css';

import('./pdms').then(pdms => {
    pdms.default.initBootstrap();
    pdms.default.init();
});
